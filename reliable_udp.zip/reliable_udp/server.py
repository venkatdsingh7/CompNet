#Dhruv Maheswari 2018A7PS0170H
#Raaed Ahmed Syed 2018A7PS0218H
#Venkateshwar Dhari SIngh 2018A7PS0246H
#Lokesh Mehra 2018A7PS0268H

from socket import socket, AF_INET, SOCK_DGRAM, error
import time
from Packet_v import Packet
from threading import Thread, Lock
from copy import deepcopy
import pickle
import traceback
from collections.abc import Hashable
import sys
import os
import signal
import server_util

def form_handshake(st,key,length):
    length = str(length)
    hshake = st+key+length
    return to_utf(hshake)

def to_utf(st):
    st = st.encode('utf-8')
    return st

def driver():
    #global connection_alive
    file_path = input("Enter path of file to be sent ->\n")
    other_file_path = input("Enter the destination path ->\n")
    time.sleep(5)

    f = open(file_path, 'rb')
    file_size = os.path.getsize(file_path)

    print("File : {} of size {} is being sent to client.".format(file_path,file_size))
    print("Destination Path {}".format(other_file_path))
        

    server_util.create_sock('localhost','localhost', 12345,  12346)
    if server_util.sock_status:
        print("Connected:")
    else:
        print("Error while connecting")

    upload = form_handshake(other_file_path,"%%$$##",file_size)
    server_util.put_pack(upload)
    b_length = 512
    data_sent = 0
    upload = f.read(b_length)
    while upload:
        server_util.put_pack(upload)
        print("sent: {} / {}".format(data_sent,file_size))
        data_sent += b_length
        upload = f.read(b_length)
        print("sent: {} / {}".format(min(data_sent,file_size),file_size))
    f.close()
    res = server_util.close()
    print('Sending Status Successful -> {}'.format(res))


def server():
    try:
        driver()
    except Exception:
        traceback.print_exc()


if __name__ == "__main__":
    server()