#Dhruv Maheswari 2018A7PS0170H
#Raaed Ahmed Syed 2018A7PS0218H
#Venkateshwar Dhari SIngh 2018A7PS0246H
#Lokesh Mehra 2018A7PS0268H

from socket import socket, AF_INET, SOCK_DGRAM, error
import time
from Packet_v import Packet
from threading import Thread, Lock
from copy import deepcopy
import pickle
import traceback
from collections.abc import Hashable
import sys
import os
import signal

vars = [1,1000,1000,1000,0.00001,1024]

data_get_buff = {}
transmit_pack = set()
receive_base = 0
my_ip = 1
my_port = 1
other_ip = 1
other_port = 1
conn_close_time = 0
sock = socket(AF_INET, SOCK_DGRAM)
sock_status = False
fin_acked = False
data_get_buff_lock = Lock()

def get_udp_pack(size,_socket):
    global sock
    try:
        temp,address = sock.recvfrom(size)
        packet = temp
        packet = pickle.loads(packet)
        return packet
    except Exception:
        return 


def put_udp_pack( recv_ip, recv_port, _socket, packet):
    global sock
    try:
        sock.sendto(pickle.dumps(packet), (recv_ip, recv_port))
    except Exception:
        traceback.print_exc()
        print("DEBUG: Error sending")




def create_sock(my_ip1,other_ip1, my_port1,  other_port1):
    global sock_status,my_ip,my_port,other_ip,other_port,sock
    my_ip = my_ip1
    my_port = my_port1
    other_ip = other_ip1
    other_port = other_port1
    
    sock.settimeout(vars[0])
    try:
        sock.bind((my_ip, my_port))
        sock_status = True
    except error as exc:
        print("DEBUG: Error binding to ", (my_ip, my_port), exc)
        sock_status = False
    get_pack_ = Thread(target=get_pack_l)
    get_pack_.setDaemon(True)
    get_pack_.start()

def get_pack_l():
    global sock_status,my_ip,my_port,other_ip,other_port,sock,fin_acked,transmit_pack,data_get_buff,receive_base,data_get_buff_lock
    while True:
        packet = get_udp_pack(vars[5],sock)

        if packet is None:
            continue
        if packet.data_type == "FIN_ACK":
            fin_acked = True
            break
        if packet.data_type == "DATA":
            if packet.load_tamper():
                continue
            if packet.seq < receive_base or packet.seq in data_get_buff.keys() or packet.seq in transmit_pack:
                tpacket = Packet(bytes("", 'utf-8'),1,"")
                put_udp_pack(other_ip, other_port,sock, tpacket.create_ack(packet.seq) )
                continue
            if packet.seq >= receive_base + vars[3]:
                continue
            if receive_base <= packet.seq < receive_base + vars[3]:
                with data_get_buff_lock:
                    data_get_buff[packet.seq] = packet
                    tpacket = Packet(bytes("", 'utf-8'),1,"")
                    put_udp_pack(other_ip, other_port,sock, tpacket.create_ack(packet.seq))

        if not sock_status:
            break

def __get_buffered_data():
    global data_get_buff,data_get_buff_lock,receive_base,transmit_pack
    if not data_get_buff:
        return None

    with data_get_buff_lock:
        seq = min(data_get_buff, default=0)
        if seq in transmit_pack:
            del data_get_buff[seq]
            return None
        if seq == receive_base:
            transmit_pack.add(seq)
            payload = data_get_buff[seq].payload
            del data_get_buff[seq]
            receive_base += 1
            return payload
        else:
            return None

def get_packets():
    while True:
        data = __get_buffered_data()
        if data is not None:
            data = deepcopy(data)
            return data
        time.sleep(vars[4])

def close():
    global fin_acked,sock_status,conn_close_time
    time.sleep(vars[0])
    count = 0
    while fin_acked is False and count < vars[2]:
        tpacket = Packet(bytes("", 'utf-8'),1,"")
        put_udp_pack(other_ip, other_port,sock, tpacket.create_fin("FIN"))
        count += 1

    sock_status = False
    time.sleep(vars[0])
    conn_close_time = time.time()
    return True