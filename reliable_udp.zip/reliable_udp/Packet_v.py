#Dhruv Maheswari 2018A7PS0170H
#Raaed Ahmed Syed 2018A7PS0218H
#Venkateshwar Dhari SIngh 2018A7PS0246H
#Lokesh Mehra 2018A7PS0268H

from zlib import adler32

def encode_utf8(s):
    return s.encode('utf-8')

def rollingCheck(load):
    s = bytes("",'utf-8')
    for i in range(len(load)):
        if(type(load[i])==bytes):
            s = s+load[i]
            continue
        else:
            load[i] = encode_utf8(str(load[i]))
            s = s+load[i]
    return adler32(s) & 0xffffffff

class Packet:
    def __init__(self, load, no, type):
        self.payload = load #payload is str
        self.seq = no
        self.data_type = type
        l = []
        l.append(self.payload)
        l.append(self.seq)
        self.checksum = rollingCheck(l)
    
    def load_tamper(self):
        l = []
        l.append(self.payload)
        l.append(self.seq)
        check = rollingCheck(l)
        return check != self.checksum

    def create_ack(self,seq):
        packet = Packet(bytes("", 'utf-8'), seq, "ACK")
        self.payload = packet.payload
        self.checksum = packet.checksum
        self.seq = packet.seq
        self.data_type = packet.data_type


    def create_data_pkt(self,data, seq):
        packet = Packet(data, seq, "DATA")
        self.payload = packet.payload
        self.checksum = packet.checksum
        self.seq = packet.seq
        self.data_type = packet.data_type

    def create_fin(self,s):
        packet = Packet(bytes("", 'utf-8'), -1, s)
        self.payload = packet.payload
        self.checksum = packet.checksum
        self.seq = packet.seq
        self.data_type = s

