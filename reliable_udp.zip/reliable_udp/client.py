#Dhruv Maheswari 2018A7PS0170H
#Raaed Ahmed Syed 2018A7PS0218H
#Venkateshwar Dhari SIngh 2018A7PS0246H
#Lokesh Mehra 2018A7PS0268H


from socket import socket, AF_INET, SOCK_DGRAM, error
import time
from Packet_v import Packet
from threading import Thread, Lock
from copy import deepcopy
import pickle
import traceback
from collections.abc import Hashable
import sys
import os
import signal
import client_util

vars = [1,1000,1000,1000,0.00001,1024]

def find_subs(st,sub_st):
    i = st.find(sub_st)
    return i

def to_ascii(st):
    st.decode('utf-8')
    return st



def driver():
    #global sock_status,my_ip,my_port,other_ip,other_port,sock,fin_acked,transmit_pack,data_get_buff,receive_base,data_get_buff_lock
    client_util.create_sock('localhost','localhost', 12346,  12345)
    if client_util.sock_status:
        print("Connected:")
    else:
        print("Error while connecting")
        return
    time.sleep(2)
    print("\nAwaiting data from Server:")
    recv_str = client_util.get_packets()
    recv_str = to_ascii(recv_str)
    handshake_token = find_subs(recv_str,b"%%$$##")
    if handshake_token == -1:
        print("Handshake packet is incorrect")
    file_path = recv_str[:handshake_token]
    file_size = int(recv_str[handshake_token+6:])
    print("File - > {} of size {} is being received ".format(file_path,file_size))
    length_recv = 0
    with open(file_path, 'wb+') as f:
        while True:
            data = client_util.get_packets()
            length_recv += len(data)
            f.write(data)
            print("received: {} out of {} bytes".format(length_recv,file_size), end="\n")
            if length_recv >= file_size:
                break
    res = client_util.close()
    print("\nFile Received Status : {}".format(res))



def client():
    try:
        driver()
    except Exception:
        traceback.print_exc()


if __name__ == "__main__":
    client()