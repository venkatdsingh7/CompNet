#Dhruv Maheswari 2018A7PS0170H
#Raaed Ahmed Syed 2018A7PS0218H
#Venkateshwar Dhari SIngh 2018A7PS0246H
#Lokesh Mehra 2018A7PS0268H

from socket import socket, AF_INET, SOCK_DGRAM, error
import time
from Packet_v import Packet
from threading import Thread, Lock
from copy import deepcopy
import pickle
import traceback
from collections.abc import Hashable
import sys
import os
import signal

vars = [1,1000,1000,1000,0.00001,1024]

def get_udp_pack(size,_socket):
    try:
        temp = sock.recvfrom(size)
        packet = temp[0]
        packet = pickle.loads(packet)
        return packet
    except Exception:
        return 

def put_udp_pack( recv_ip, recv_port, _socket, packet,):
    try:
        sock.sendto(pickle.dumps(packet), (recv_ip, recv_port))
    except Exception:
        traceback.print_exc()
        print("DEBUG: Error sending")

def form_handshake(st,key,length):
    length = str(length)
    hshake = st+key+length
    return to_utf(hshake)

def to_utf(st):
    st = st.encode('utf-8')
    return st

puts_buffer = {}
retry_count = {}
acked = set()
puts_base = 0
my_ip = 1
my_port = 1
other_ip = 1
other_port = 1
seq_num = 0
conn_close_time = 0
sock_status = False
puts_buffer_para = Lock()
seq_num_para = Lock()
sock_puts_para = Lock()
puts_base_para = Lock()
sock = socket(AF_INET, SOCK_DGRAM)
sock.settimeout(vars[0])
packet_get_ = Thread()


def create_sock(my_ip1, other_ip1,my_port1, other_port1):
    global puts_buffer,retry_count,acked,puts_base,my_ip,my_port,other_ip,other_port,seq_num,conn_close_time,sock_status,puts_buffer_para,seq_num_para,sock_puts_para,puts_base_para,sock
    my_ip = my_ip1
    my_port = my_port1
    other_ip = other_ip1
    other_port = other_port1
    try:
        sock.bind((my_ip, my_port))
        sock_status = True
    except:
        sock_status = False

    packet_get_ = Thread(target=get_pack_l)
    packet_get_.setDaemon(True)
    packet_get_.start()

    packet_send_again = Thread(target=__send_again)
    packet_send_again.setDaemon(True)
    packet_send_again.start()

def get_pack_l():
    global puts_buffer,retry_count,acked,puts_base,my_ip,my_port,other_ip,other_port,seq_num,conn_close_time,sock_status,puts_buffer_para,seq_num_para,sock_puts_para,puts_base_para,sock
    while True:
        packet = get_udp_pack(vars[5],sock)

        if packet is None:
            continue

        if packet.data_type == "FIN":
            with puts_buffer_para:
                puts_buffer.clear()
            puts_fin_ack()
            break

        if packet.data_type == "ACK":
            if packet.seq < puts_base:
                continue

            with puts_buffer_para:
                if packet.seq in puts_buffer.keys():
                    del puts_buffer[packet.seq]

            acked.add(packet.seq)
            with puts_base_para:
                first_not_acked = puts_base
                for i in range(puts_base, puts_base+vars[3]+2):
                    if i not in acked:
                        first_not_acked = i
                        break
                puts_base = first_not_acked
        if sock_status is False:
            os.kill(os.getpid(), signal.SIGINT)
            sys.exit()
            

def __send(packet, retransmit=False):
    global puts_buffer,retry_count,acked,puts_base,my_ip,my_port,other_ip,other_port,seq_num,conn_close_time,sock_status,puts_buffer_para,seq_num_para,sock_puts_para,puts_base_para,sock
    if not retransmit:
        with puts_buffer_para:
            puts_buffer[packet.seq] = (packet, time.time())

    try:
        with sock_puts_para:
            put_udp_pack(other_ip, other_port,sock, packet)
    except Exception as _:
         return

def is_puts_buffer_full():
    global puts_buffer,retry_count,acked,puts_base,my_ip,my_port,other_ip,other_port,seq_num,conn_close_time,sock_status,puts_buffer_para,seq_num_para,sock_puts_para,puts_base_para,sock
    with seq_num_para:
        if seq_num <= puts_base + vars[3]:
            seq = seq_num
            seq_num += 1
            return seq
        else:
            return -1

def put_pack(data):
    global puts_buffer,retry_count,acked,puts_base,my_ip,my_port,other_ip,other_port,seq_num,conn_close_time,sock_status,puts_buffer_para,seq_num_para,sock_puts_para,puts_base_para,sock
    if not isinstance(data, Hashable):
        raise Exception("Error")

    seq = -1
    while True:
        seq = is_puts_buffer_full()
        if seq == -1:
            time.sleep(vars[4])
        else:
            break

    data = deepcopy(data)
    tpacket = Packet(bytes("", 'utf-8'),1,"")
    tpacket.create_data_pkt(data, seq)
    packet = tpacket
    __send(packet)

def __send_again():
    global puts_buffer,retry_count,acked,puts_base,my_ip,my_port,other_ip,other_port,seq_num,conn_close_time,sock_status,puts_buffer_para,seq_num_para,sock_puts_para,puts_base_para,sock
    try:
        while True:
            time.sleep(vars[0])
            if sock_status is False and not puts_buffer:
                return
            with puts_buffer_para:
                for seq in puts_buffer.keys():
                    if seq not in retry_count.keys():
                        retry_count[seq] = 0

                    (packet, pkt_transmission_time) = puts_buffer[seq]
                    time_now = time.time()
                    if (time_now - pkt_transmission_time) >= vars[0]:
                        if retry_count[seq] > vars[2]:
                            force_close()
                        puts_buffer[packet.seq] = (packet, time.time())
                        retry_count[seq] += 1
                        __send(packet, retransmit=True)
    except Exception:
        traceback.print_exc()

def puts_fin_ack():
    global puts_buffer,retry_count,acked,puts_base,my_ip,my_port,other_ip,other_port,seq_num,conn_close_time,sock_status,puts_buffer_para,seq_num_para,sock_puts_para,puts_base_para,sock
    for i in range(vars[2]):
        tpacket = Packet(bytes("", 'utf-8'),1,"")
        put_udp_pack(other_ip, other_port,sock, tpacket.create_fin("FIN_ACK") )

    close()

def close():
    global puts_buffer,retry_count,acked,puts_base,my_ip,my_port,other_ip,other_port,seq_num,conn_close_time,sock_status,puts_buffer_para,seq_num_para,sock_puts_para,puts_base_para,sock,packet_get_
    c=0
    while puts_buffer and c<10:
        time.sleep(vars[4])
        c+=1

    sock_status = False
    time.sleep(vars[0])
    conn_close_time = time.time()
    return True

def force_close():
    global puts_buffer,retry_count,acked,puts_base,my_ip,my_port,other_ip,other_port,seq_num,conn_close_time,sock_status,puts_buffer_para,seq_num_para,sock_puts_para,puts_base_para,sock
    sock_status = False
    conn_close_time = time.time()
    time.sleep(5)
    os.kill(os.getpid(), signal.SIGINT)
    sys.exit()