Compilation and Running Instructions:
**All files should be in same folder**

For Server(For sending):
python server.py
Enter location of file to be sent(eg: F:\send.txt)
Enter location at which file will be stored(eg: F:\receive.txt)

For Client(For receiving):
python client.py

Changes made from design document during implementation:
Sequence number will always start from zero instead of file size.